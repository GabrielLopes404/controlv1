import { useState } from "react";
import { projects, clients } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Filter, Calendar, DollarSign, LayoutGrid, List, MoreVertical, Clock, CheckCircle2, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const item = {
  hidden: { opacity: 0, scale: 0.95 },
  show: { opacity: 1, scale: 1 }
};

export default function Projects() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredProjects = projects.filter(
    (project) =>
      project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      clients.find(c => c.id === project.clientId)?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "in_progress": return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "completed": return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
      case "proposal": return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      case "review": return "bg-purple-500/10 text-purple-500 border-purple-500/20";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Projetos</h1>
          <p className="text-muted-foreground">Gerencie suas entregas e cronogramas.</p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)] hover:scale-105 transition-transform">
            <Plus className="w-4 h-4 mr-2" /> Novo Projeto
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between bg-card/40 p-2 rounded-xl border border-border/50 backdrop-blur-sm sticky top-20 z-10 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-auto flex-1">
            <Search className="w-5 h-5 text-muted-foreground ml-2" />
            <Input 
            placeholder="Buscar projetos..." 
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 w-full"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            />
        </div>
        <div className="flex items-center gap-2">
            <div className="bg-muted/50 p-1 rounded-lg flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => setViewMode("grid")} className={cn("h-8 w-8 rounded-md transition-all", viewMode === "grid" && "bg-background shadow-sm text-foreground")}>
                  <LayoutGrid className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setViewMode("list")} className={cn("h-8 w-8 rounded-md transition-all", viewMode === "list" && "bg-background shadow-sm text-foreground")}>
                  <List className="w-4 h-4" />
              </Button>
            </div>
            <Button variant="outline" size="sm" className="gap-2 h-10 border-border/60">
                <Filter className="w-4 h-4" /> Filtros
            </Button>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className={cn(
            "grid gap-6",
            viewMode === "grid" ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"
        )}
      >
        {filteredProjects.map((project) => (
          <motion.div key={project.id} variants={item}>
            <Card className="group hover:border-primary/50 transition-all duration-300 h-full flex flex-col overflow-hidden bg-card/40 backdrop-blur border-border/60 hover:shadow-lg hover:shadow-primary/5">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start mb-3">
                    <Badge variant="outline" className={cn("uppercase text-[10px] font-bold tracking-wider py-1 px-2", getStatusColor(project.status))}>
                        {project.status.replace("_", " ")}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
                          <MoreVertical className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>Editar</DropdownMenuItem>
                        <DropdownMenuItem>Duplicar</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">Arquivar</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                </div>
                <CardTitle className="text-xl font-bold leading-tight group-hover:text-primary transition-colors cursor-pointer">
                  {project.title}
                </CardTitle>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                    {clients.find(c => c.id === project.clientId)?.name}
                </p>
              </CardHeader>
              
              <CardContent className="flex-1 flex flex-col gap-4">
                <div className="space-y-2 mt-auto">
                    <div className="flex justify-between text-xs font-medium text-muted-foreground">
                        <span>Progresso</span>
                        <span className={cn(project.progress === 100 ? "text-emerald-500" : "text-primary")}>{project.progress}%</span>
                    </div>
                    <Progress value={project.progress} className="h-1.5" />
                </div>

                <div className="flex items-center justify-between text-sm pt-4 border-t border-border/50">
                    <div className="flex items-center gap-1.5 text-muted-foreground bg-muted/30 px-2 py-1 rounded">
                        <Calendar className="w-3.5 h-3.5" />
                        <span className="text-xs font-medium">{new Date(project.deadline).toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' })}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono font-bold text-foreground">
                        <DollarSign className="w-3.5 h-3.5 text-muted-foreground" />
                        <span>{project.budget.toLocaleString('pt-BR')}</span>
                    </div>
                </div>
                
                <div className="flex gap-2 flex-wrap mt-1">
                    {project.tags.map(tag => (
                        <Badge key={tag} variant="secondary" className="text-[10px] font-normal text-muted-foreground bg-muted/50 hover:bg-muted">
                            {tag}
                        </Badge>
                    ))}
                </div>
              </CardContent>
              
              <CardFooter className="pt-0 pb-4 px-6 opacity-0 group-hover:opacity-100 transition-opacity -translate-y-2 group-hover:translate-y-0 duration-300">
                <Button className="w-full h-8 text-xs bg-primary/10 text-primary hover:bg-primary hover:text-white border-0">
                   Ver Detalhes <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
