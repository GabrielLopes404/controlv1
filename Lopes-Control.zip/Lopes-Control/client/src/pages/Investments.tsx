import { useState } from "react";
import { investments } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, DollarSign, PieChart, Plus, Wallet, ArrowUpRight } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  PieChart as RePieChart, Pie, Cell, Tooltip, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid
} from 'recharts';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

const COLORS = ['#FF00AA', '#3b82f6', '#10b981', '#eab308'];

const portfolioHistory = [
  { month: 'Jan', value: 10000 },
  { month: 'Fev', value: 11500 },
  { month: 'Mar', value: 11200 },
  { month: 'Abr', value: 13800 },
  { month: 'Mai', value: 15100 },
  { month: 'Jun', value: 16500 },
];

export default function Investments() {
  const totalInvested = investments.reduce((acc, curr) => acc + curr.currentTotal, 0);
  const totalProfit = investments.reduce((acc, curr) => acc + curr.profit, 0);
  const totalProfitPercent = (totalProfit / (totalInvested - totalProfit)) * 100;

  const allocationData = investments.map(inv => ({
    name: inv.type,
    value: inv.currentTotal
  }));

  // Group by type for the chart
  const groupedAllocation = allocationData.reduce((acc: any, curr) => {
    const existing = acc.find((a: any) => a.name === curr.name);
    if (existing) {
      existing.value += curr.value;
    } else {
      acc.push({ ...curr });
    }
    return acc;
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Investimentos</h1>
          <p className="text-muted-foreground">Acompanhe a evolução do seu patrimônio pessoal.</p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)] hover:scale-105 transition-transform">
            <Plus className="w-4 h-4 mr-2" /> Novo Aporte
          </Button>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
      >
        <motion.div variants={item}>
          <Card className="bg-card/40 backdrop-blur-sm border-border/60 hover:shadow-lg transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-xl text-primary">
                  <Wallet className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">Patrimônio Total</p>
                  <h3 className="text-2xl font-bold font-heading">R$ {totalInvested.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="bg-card/40 backdrop-blur-sm border-border/60 hover:shadow-lg transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-500">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">Lucro Total</p>
                  <h3 className="text-2xl font-bold font-heading flex items-center gap-2">
                    R$ {totalProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    <Badge variant="outline" className="text-emerald-500 border-emerald-500/30 bg-emerald-500/10 text-[10px] flex items-center">
                      <ArrowUpRight className="w-3 h-3 mr-0.5" />
                      {totalProfitPercent.toFixed(2)}%
                    </Badge>
                  </h3>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="bg-card/40 backdrop-blur-sm border-border/60 hover:shadow-lg transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-500/10 rounded-xl text-blue-500">
                  <DollarSign className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">Aporte Mensal</p>
                  <h3 className="text-2xl font-bold font-heading">R$ 1.500,00</h3>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div variants={item} className="lg:col-span-2 space-y-6">
          
          {/* Portfolio History Chart */}
          <Card className="border-border/60 bg-card/40 backdrop-blur-sm">
             <CardHeader>
               <CardTitle>Crescimento Patrimonial</CardTitle>
             </CardHeader>
             <CardContent className="h-[250px]">
               <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={portfolioHistory}>
                   <defs>
                     <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                       <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                       <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                     </linearGradient>
                   </defs>
                   <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} vertical={false} />
                   <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" axisLine={false} tickLine={false} />
                   <YAxis stroke="hsl(var(--muted-foreground))" axisLine={false} tickLine={false} tickFormatter={(val) => `R$${val/1000}k`} />
                   <Tooltip 
                     contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))', borderRadius: '8px' }}
                     itemStyle={{ color: 'hsl(var(--foreground))' }}
                   />
                   <Area type="monotone" dataKey="value" stroke="#10b981" fillOpacity={1} fill="url(#colorValue)" strokeWidth={3} />
                 </AreaChart>
               </ResponsiveContainer>
             </CardContent>
          </Card>

          <Card className="border-border/60 bg-card/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Minha Carteira</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/30 text-muted-foreground font-medium uppercase text-xs">
                    <tr className="border-b border-border/50">
                      <th className="px-6 py-4 text-left">Ativo</th>
                      <th className="px-6 py-4 text-left">Tipo</th>
                      <th className="px-6 py-4 text-right">Qtd</th>
                      <th className="px-6 py-4 text-right">Preço Médio</th>
                      <th className="px-6 py-4 text-right">Atual</th>
                      <th className="px-6 py-4 text-right">Total</th>
                      <th className="px-6 py-4 text-right">Rentab.</th>
                    </tr>
                  </thead>
                  <tbody>
                    {investments.map((inv) => (
                      <tr key={inv.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors">
                        <td className="px-6 py-4">
                          <div className="font-bold">{inv.ticker}</div>
                          <div className="text-xs text-muted-foreground">{inv.name}</div>
                        </td>
                        <td className="px-6 py-4 capitalize">
                          <Badge variant="secondary" className="font-normal text-[10px] bg-muted/50">{inv.type}</Badge>
                        </td>
                        <td className="px-6 py-4 text-right">{inv.quantity}</td>
                        <td className="px-6 py-4 text-right text-muted-foreground">R$ {inv.averagePrice.toLocaleString('pt-BR')}</td>
                        <td className="px-6 py-4 text-right">R$ {inv.currentPrice.toLocaleString('pt-BR')}</td>
                        <td className="px-6 py-4 text-right font-bold">R$ {inv.currentTotal.toLocaleString('pt-BR')}</td>
                        <td className={cn(
                          "px-6 py-4 text-right font-bold",
                          inv.profit >= 0 ? "text-emerald-500" : "text-red-500"
                        )}>
                          {inv.profit >= 0 ? "+" : ""}{inv.profitPercent.toFixed(2)}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="h-full border-border/60 bg-card/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Alocação</CardTitle>
            </CardHeader>
            <CardContent className="h-[300px] flex flex-col items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={groupedAllocation}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {groupedAllocation.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} strokeWidth={0} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR')}`}
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))', borderRadius: '8px' }}
                    itemStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                </RePieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap justify-center gap-3 text-xs text-muted-foreground mt-[-20px] px-4">
                {groupedAllocation.map((entry: any, index: number) => (
                  <div key={entry.name} className="flex items-center gap-1.5 capitalize">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                    {entry.name}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
