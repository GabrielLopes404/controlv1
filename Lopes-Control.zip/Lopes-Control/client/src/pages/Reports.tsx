import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, PieChart, Pie, Cell, ComposedChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend
} from 'recharts';
import { Download, Calendar, Activity, Zap, Target } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, scale: 0.95 },
  show: { opacity: 1, scale: 1 }
};

const revenueData = [
  { name: 'Jan', revenue: 4000, goal: 5000 },
  { name: 'Fev', revenue: 3000, goal: 5000 },
  { name: 'Mar', revenue: 2000, goal: 5500 },
  { name: 'Abr', revenue: 2780, goal: 5500 },
  { name: 'Mai', revenue: 6890, goal: 6000 },
  { name: 'Jun', revenue: 2390, goal: 6000 },
  { name: 'Jul', revenue: 8490, goal: 7000 },
];

const hoursData = [
  { name: 'Seg', hours: 4, focus: 3 },
  { name: 'Ter', hours: 6, focus: 4 },
  { name: 'Qua', hours: 8, focus: 7 },
  { name: 'Qui', hours: 5, focus: 2 },
  { name: 'Sex', hours: 7, focus: 6 },
  { name: 'Sáb', hours: 2, focus: 1 },
  { name: 'Dom', hours: 0, focus: 0 },
];

const projectStatusData = [
  { name: 'Em Progresso', value: 4, color: '#3b82f6' }, // blue
  { name: 'Concluídos', value: 12, color: '#10b981' }, // emerald
  { name: 'Cancelados', value: 1, color: '#ef4444' }, // red
  { name: 'Pausados', value: 2, color: '#eab308' }, // yellow
];

const skillsData = [
  { subject: 'Web Design', A: 120, fullMark: 150 },
  { subject: 'Branding', A: 98, fullMark: 150 },
  { subject: 'Coding', A: 86, fullMark: 150 },
  { subject: 'SEO', A: 99, fullMark: 150 },
  { subject: 'Social', A: 85, fullMark: 150 },
  { subject: 'Copy', A: 65, fullMark: 150 },
];

export default function Reports() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Relatórios</h1>
          <p className="text-muted-foreground">Análises detalhadas de performance e financeiro.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2 border-border/60">
            <Calendar className="w-4 h-4" /> Últimos 6 meses
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)] hover:scale-105 transition-transform">
            <Download className="w-4 h-4 mr-2" /> Exportar PDF
          </Button>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
      >
        <motion.div variants={item} className="lg:col-span-3">
          <Card className="border-border/60 bg-card/40 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                 <CardTitle className="text-xl">Receita vs Meta</CardTitle>
                 <p className="text-sm text-muted-foreground">Comparativo mensal de faturamento</p>
              </div>
              <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">
                <Target className="w-3 h-3 mr-1" /> Meta Batida!
              </Badge>
            </CardHeader>
            <CardContent className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={revenueData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#FF00AA" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#FF00AA" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} vertical={false} />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" axisLine={false} tickLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" axisLine={false} tickLine={false} tickFormatter={(value) => `R$${value/1000}k`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))', borderRadius: '8px' }}
                    itemStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                  <Legend />
                  <Area type="monotone" dataKey="revenue" fill="url(#colorRevenue)" stroke="#FF00AA" strokeWidth={3} name="Receita" />
                  <Line type="monotone" dataKey="goal" stroke="#10b981" strokeDasharray="5 5" strokeWidth={2} name="Meta" dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item} className="lg:col-span-1">
          <Card className="h-full border-border/60 bg-card/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-lg">Performance por Niche</CardTitle>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={skillsData}>
                  <PolarGrid stroke="hsl(var(--border))" opacity={0.5} />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 150]} tick={false} axisLine={false} />
                  <Radar name="Skills" dataKey="A" stroke="#FF00AA" fill="#FF00AA" fillOpacity={0.4} />
                  <Tooltip 
                     contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item} className="lg:col-span-2">
          <Card className="border-border/60 bg-card/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Produtividade Semanal</CardTitle>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={hoursData} barSize={40}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} vertical={false} />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" axisLine={false} tickLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" axisLine={false} tickLine={false} />
                  <Tooltip 
                    cursor={{fill: 'hsl(var(--muted)/0.3)'}}
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))', borderRadius: '8px' }}
                  />
                  <Legend />
                  <Bar dataKey="hours" name="Horas Totais" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="focus" name="Deep Work" fill="#a855f7" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item} className="lg:col-span-2">
          <Card className="border-border/60 bg-card/40 backdrop-blur-sm h-full">
            <CardHeader>
              <CardTitle>Status dos Projetos</CardTitle>
            </CardHeader>
            <CardContent className="h-[300px] flex flex-col items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={projectStatusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {projectStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))', borderRadius: '8px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap justify-center gap-4 text-xs text-muted-foreground mt-[-20px]">
                {projectStatusData.map((entry) => (
                  <div key={entry.name} className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                    <span className="font-medium">{entry.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  );
}
