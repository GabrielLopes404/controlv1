import { useState } from "react";
import { goals } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Target, Trophy, TrendingUp, Plus, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function Goals() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Metas</h1>
          <p className="text-muted-foreground">Acompanhe seu progresso e conquiste objetivos.</p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)]">
            <Plus className="w-4 h-4 mr-2" /> Nova Meta
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-yellow-500/10 to-transparent border-yellow-500/20">
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-4 bg-yellow-500/20 rounded-full text-yellow-500">
              <Trophy className="w-8 h-8" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground font-bold uppercase">Nível Atual</p>
              <h3 className="text-2xl font-bold font-heading text-yellow-500">Gold Freelancer</h3>
              <p className="text-xs text-muted-foreground mt-1">Top 5% de faturamento</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="col-span-2 bg-gradient-to-r from-primary/5 to-transparent border-primary/20">
            <CardContent className="p-6">
                <div className="flex justify-between items-center mb-2">
                    <h3 className="font-bold text-lg flex items-center gap-2">
                        <TrendingUp className="w-5 h-5 text-primary" /> Progresso do Mês
                    </h3>
                    <span className="font-mono font-bold text-primary">75%</span>
                </div>
                <Progress value={75} className="h-4 bg-muted" />
                <p className="text-sm text-muted-foreground mt-2">Você está a apenas 2 projetos de atingir sua meta mensal!</p>
            </CardContent>
        </Card>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {goals.map((goal) => {
            const percentage = Math.min((goal.current / goal.target) * 100, 100);
            return (
                <motion.div key={goal.id} variants={item}>
                    <Card className="relative overflow-hidden group hover:border-primary/50 transition-all">
                        <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
                        <CardHeader className="pb-2">
                            <div className="flex justify-between items-start">
                                <Badge variant="outline" className="uppercase text-[10px] mb-2">{goal.period === 'daily' ? 'Diária' : goal.period === 'weekly' ? 'Semanal' : 'Mensal'}</Badge>
                                <Target className="w-4 h-4 text-muted-foreground" />
                            </div>
                            <CardTitle className="text-lg">{goal.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="flex justify-between items-end mb-2">
                                <span className="text-3xl font-bold font-heading">
                                    {goal.unit === 'R$' ? 'R$ ' : ''}{goal.current.toLocaleString('pt-BR')}
                                </span>
                                <span className="text-sm text-muted-foreground mb-1">
                                    / {goal.unit === 'R$' ? 'R$ ' : ''}{goal.target.toLocaleString('pt-BR')} {goal.unit !== 'R$' && goal.unit}
                                </span>
                            </div>
                            <Progress value={percentage} className={cn("h-2", percentage >= 100 ? "bg-emerald-500/20" : "")} />
                            {percentage >= 100 && (
                                <div className="mt-4 flex items-center justify-center gap-2 text-emerald-500 font-bold text-sm bg-emerald-500/10 py-2 rounded">
                                    <Trophy className="w-4 h-4" /> Meta Concluída!
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </motion.div>
            );
        })}
        
        <motion.div variants={item} className="flex items-center justify-center border-2 border-dashed border-border rounded-xl p-6 hover:bg-muted/10 cursor-pointer transition-colors group">
            <div className="text-center">
                <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-3 group-hover:bg-primary/20 group-hover:text-primary transition-colors">
                    <Plus className="w-6 h-6 text-muted-foreground group-hover:text-primary" />
                </div>
                <h3 className="font-bold text-muted-foreground group-hover:text-foreground">Criar Nova Meta</h3>
            </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
