import { useState } from "react";
import { clients } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Phone, Video, MoreVertical, Paperclip, Image as ImageIcon, Smile } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

const messages = [
  { id: 1, sender: "client", text: "Olá! Conseguimos adiantar a reunião de amanhã?", time: "09:30", clientId: "1" },
  { id: 2, sender: "me", text: "Bom dia! Claro, qual horário fica bom para você?", time: "09:32", clientId: "1" },
  { id: 3, sender: "client", text: "Pode ser às 14h?", time: "09:35", clientId: "1" },
  { id: 4, sender: "me", text: "Combinado! Te envio o invite.", time: "09:35", clientId: "1" },
  { id: 5, sender: "client", text: "Perfeito, obrigado!", time: "09:36", clientId: "1" },
];

export default function Chat() {
  const [selectedClient, setSelectedClient] = useState(clients[0]);
  const [newMessage, setNewMessage] = useState("");

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] md:h-[calc(100vh-100px)] gap-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Chat</h1>
          <p className="text-muted-foreground">Comunicação direta com seus clientes.</p>
        </div>
      </div>

      <Card className="flex-1 flex overflow-hidden border-border bg-card/50 backdrop-blur-sm">
        {/* Sidebar List */}
        <div className="w-full md:w-80 border-r border-border flex flex-col bg-muted/10">
          <div className="p-4 border-b border-border">
            <Input placeholder="Buscar conversa..." className="bg-background" />
          </div>
          <ScrollArea className="flex-1">
            <div className="flex flex-col">
              {clients.map((client) => (
                <button
                  key={client.id}
                  onClick={() => setSelectedClient(client)}
                  className={cn(
                    "flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors text-left border-l-2",
                    selectedClient.id === client.id 
                      ? "bg-primary/5 border-primary" 
                      : "border-transparent"
                  )}
                >
                  <div className="relative">
                    <Avatar>
                      <AvatarImage src={client.avatar} />
                      <AvatarFallback>{client.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <span className={cn(
                      "absolute bottom-0 right-0 w-3 h-3 border-2 border-background rounded-full",
                      client.status === "active" ? "bg-emerald-500" : "bg-muted-foreground"
                    )} />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-semibold text-sm truncate">{client.name}</span>
                      <span className="text-[10px] text-muted-foreground">09:30</span>
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      {client.company}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Chat Area */}
        <div className="hidden md:flex flex-1 flex-col bg-background">
          {/* Header */}
          <div className="h-16 border-b border-border flex items-center justify-between px-6 bg-card/30">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarImage src={selectedClient.avatar} />
                <AvatarFallback>{selectedClient.name.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-bold text-sm">{selectedClient.name}</h3>
                <p className="text-xs text-emerald-500 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" /> Online agora
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon"><Phone className="w-5 h-5 text-muted-foreground" /></Button>
              <Button variant="ghost" size="icon"><Video className="w-5 h-5 text-muted-foreground" /></Button>
              <Button variant="ghost" size="icon"><MoreVertical className="w-5 h-5 text-muted-foreground" /></Button>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-6 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] bg-opacity-5">
            <div className="space-y-4">
              <div className="flex justify-center">
                <Badge variant="outline" className="text-xs text-muted-foreground border-border bg-muted/30">Hoje</Badge>
              </div>
              
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={cn(
                    "flex gap-3 max-w-[80%]",
                    msg.sender === "me" ? "ml-auto flex-row-reverse" : ""
                  )}
                >
                  <Avatar className="w-8 h-8 mt-1">
                    <AvatarFallback className={cn("text-xs", msg.sender === "me" ? "bg-primary text-primary-foreground" : "")}>
                      {msg.sender === "me" ? "EU" : selectedClient.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className={cn(
                    "p-3 rounded-2xl text-sm shadow-sm",
                    msg.sender === "me" 
                      ? "bg-primary text-primary-foreground rounded-tr-sm" 
                      : "bg-muted rounded-tl-sm border border-border"
                  )}>
                    <p>{msg.text}</p>
                    <span className={cn(
                      "text-[10px] block text-right mt-1 opacity-70",
                      msg.sender === "me" ? "text-primary-foreground" : "text-muted-foreground"
                    )}>
                      {msg.time}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Input */}
          <div className="p-4 border-t border-border bg-card/30">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="shrink-0"><Paperclip className="w-5 h-5 text-muted-foreground" /></Button>
              <Input 
                placeholder="Digite sua mensagem..." 
                className="flex-1 bg-muted/50 border-0 focus-visible:ring-1 focus-visible:ring-primary"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
              />
              <Button variant="ghost" size="icon" className="shrink-0"><Smile className="w-5 h-5 text-muted-foreground" /></Button>
              <Button size="icon" className="shrink-0 bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_15px_rgba(255,0,170,0.4)]">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
