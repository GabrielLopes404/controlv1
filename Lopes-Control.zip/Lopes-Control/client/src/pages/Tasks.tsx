import { useState } from "react";
import { tasks, projects } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Filter, Clock, Play, Pause, MoreHorizontal, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
  defaultDropAnimationSideEffects,
  DragStartEvent,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

// Sortable Item Component
function SortableTask({ task, projectTitle }: { task: any, projectTitle: string | undefined }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: task.id, data: { task } });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-red-500 bg-red-500/10 border-red-500/20";
      case "medium": return "text-yellow-500 bg-yellow-500/10 border-yellow-500/20";
      case "low": return "text-blue-500 bg-blue-500/10 border-blue-500/20";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div 
      ref={setNodeRef} 
      style={style} 
      {...attributes} 
      {...listeners}
      className="bg-card border border-border p-3 rounded-lg shadow-sm hover:border-primary/50 cursor-grab active:cursor-grabbing mb-3 group"
    >
      <div className="flex justify-between items-start mb-2">
        <Badge variant="outline" className={cn("text-[10px] h-5 px-1.5 uppercase font-bold", getPriorityColor(task.priority))}>
          {task.priority}
        </Badge>
        <Button variant="ghost" className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
          <MoreHorizontal className="w-4 h-4" />
        </Button>
      </div>
      <h4 className="font-medium text-sm mb-1">{task.title}</h4>
      <p className="text-xs text-muted-foreground mb-3">{projectTitle}</p>
      
      <div className="flex items-center justify-between border-t border-border pt-2 mt-2">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Calendar className="w-3 h-3" />
          <span>{new Date(task.dueDate).toLocaleDateString('pt-BR', {day: '2-digit', month: 'short'})}</span>
        </div>
        {task.timeTracked && (
          <div className="flex items-center gap-1 text-xs font-mono text-primary bg-primary/10 px-1.5 py-0.5 rounded">
            <Clock className="w-3 h-3" />
            <span>{Math.floor(task.timeTracked / 60)}h {task.timeTracked % 60}m</span>
          </div>
        )}
      </div>
      
      {task.isTracking && (
        <div className="mt-2 flex items-center justify-center gap-2 bg-primary/10 text-primary text-xs py-1 rounded animate-pulse">
          <Play className="w-3 h-3 fill-current" />
          <span className="font-bold">Em andamento...</span>
        </div>
      )}
    </div>
  );
}

// Column Component
function KanbanColumn({ id, title, tasks, projects }: { id: string, title: string, tasks: any[], projects: any[] }) {
  return (
    <div className="flex-1 min-w-[280px] flex flex-col h-full bg-muted/20 rounded-xl border border-border/50 p-3">
      <div className="flex items-center justify-between mb-4 px-1">
        <h3 className="font-heading font-bold text-sm uppercase tracking-wider flex items-center gap-2">
          <span className={cn(
            "w-2 h-2 rounded-full",
            id === "todo" ? "bg-blue-500" :
            id === "in_progress" ? "bg-yellow-500" :
            id === "review" ? "bg-purple-500" : "bg-emerald-500"
          )} />
          {title}
        </h3>
        <Badge variant="secondary" className="text-xs">{tasks.length}</Badge>
      </div>
      
      <div className="flex-1 overflow-y-auto pr-1 custom-scrollbar">
        <SortableContext 
          id={id}
          items={tasks.map(t => t.id)} 
          strategy={verticalListSortingStrategy}
        >
          {tasks.map(task => (
            <SortableTask 
              key={task.id} 
              task={task} 
              projectTitle={projects.find(p => p.id === task.projectId)?.title} 
            />
          ))}
        </SortableContext>
        {tasks.length === 0 && (
          <div className="h-24 flex items-center justify-center border-2 border-dashed border-border/50 rounded-lg text-muted-foreground text-xs">
            Arraste tarefas aqui
          </div>
        )}
      </div>
    </div>
  );
}

export default function Tasks() {
  const [items, setItems] = useState(tasks);
  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const columns = [
    { id: 'todo', title: 'A Fazer' },
    { id: 'in_progress', title: 'Em Andamento' },
    { id: 'review', title: 'Revisão' },
    { id: 'done', title: 'Concluído' },
  ];

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (!over) {
      setActiveId(null);
      return;
    }

    const activeTask = items.find(t => t.id === active.id);
    const overId = over.id;
    
    // Find if dropped over a column or a task
    let newStatus = overId as string;
    
    // If dropped over a task, find that task's status
    const overTask = items.find(t => t.id === overId);
    if (overTask) {
      newStatus = overTask.status;
    } else if (!columns.find(c => c.id === overId)) {
       // If not a known column and not a task, maybe it's a container (shouldn't happen with this setup usually but good safety)
       setActiveId(null);
       return;
    }

    if (activeTask && activeTask.status !== newStatus) {
      setItems(items.map(t => 
        t.id === active.id ? { ...t, status: newStatus as any } : t
      ));
    }

    setActiveId(null);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-100px)]">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Kanban</h1>
          <p className="text-muted-foreground">Gerencie o fluxo de trabalho dos seus projetos.</p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)]">
            <Plus className="w-4 h-4 mr-2" /> Nova Tarefa
          </Button>
        </div>
      </div>

      <DndContext 
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <div className="flex-1 flex overflow-x-auto gap-4 pb-4">
          {columns.map(col => (
            <KanbanColumn 
              key={col.id} 
              id={col.id} 
              title={col.title} 
              tasks={items.filter(t => t.status === col.id)}
              projects={projects}
            />
          ))}
        </div>

        <DragOverlay dropAnimation={{ sideEffects: defaultDropAnimationSideEffects({ styles: { active: { opacity: '0.5' } } }) }}>
          {activeId ? (
            <div className="bg-card border border-border p-3 rounded-lg shadow-xl cursor-grabbing rotate-2 w-[280px]">
               {/* Simplified preview */}
               <h4 className="font-medium text-sm mb-1">{items.find(t => t.id === activeId)?.title}</h4>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>
    </div>
  );
}
