import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { motion } from "framer-motion";
import { User, Bell, Shield, Palette, Save } from "lucide-react";

export default function Settings() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Configurações</h1>
          <p className="text-muted-foreground">Gerencie suas preferências e perfil.</p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)]">
            <Save className="w-4 h-4 mr-2" /> Salvar Alterações
          </Button>
        </div>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <div className="flex flex-col md:flex-row gap-6">
          <aside className="w-full md:w-64 space-y-2">
            <TabsList className="flex flex-col h-auto bg-transparent p-0 space-y-1 w-full justify-start">
              <TabsTrigger 
                value="profile" 
                className="w-full justify-start px-4 py-2 data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
              >
                <User className="w-4 h-4 mr-2" /> Perfil
              </TabsTrigger>
              <TabsTrigger 
                value="appearance" 
                className="w-full justify-start px-4 py-2 data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
              >
                <Palette className="w-4 h-4 mr-2" /> Aparência
              </TabsTrigger>
              <TabsTrigger 
                value="notifications" 
                className="w-full justify-start px-4 py-2 data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
              >
                <Bell className="w-4 h-4 mr-2" /> Notificações
              </TabsTrigger>
              <TabsTrigger 
                value="security" 
                className="w-full justify-start px-4 py-2 data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
              >
                <Shield className="w-4 h-4 mr-2" /> Segurança
              </TabsTrigger>
            </TabsList>
          </aside>

          <div className="flex-1">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <TabsContent value="profile" className="m-0 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Informações Pessoais</CardTitle>
                    <CardDescription>Atualize sua foto e dados de contato.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center gap-6">
                      <Avatar className="w-20 h-20 border-2 border-primary">
                        <AvatarImage src="" />
                        <AvatarFallback className="text-xl bg-muted">DL</AvatarFallback>
                      </Avatar>
                      <Button variant="outline">Alterar foto</Button>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nome Completo</Label>
                        <Input id="name" defaultValue="Design Lopes" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">E-mail</Label>
                        <Input id="email" defaultValue="contato@designlopes.com" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Telefone</Label>
                        <Input id="phone" defaultValue="(11) 99999-9999" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="role">Cargo</Label>
                        <Input id="role" defaultValue="Designer Freelancer" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Input id="bio" defaultValue="Especialista em identidades visuais e web design." />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="appearance" className="m-0 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Tema</CardTitle>
                    <CardDescription>Customize a aparência do sistema.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Modo Escuro</Label>
                        <p className="text-sm text-muted-foreground">Ativar tema escuro em todo o sistema</p>
                      </div>
                      <Switch checked={true} />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Animações Reduzidas</Label>
                        <p className="text-sm text-muted-foreground">Desativar transições para melhor performance</p>
                      </div>
                      <Switch />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="notifications" className="m-0 space-y-6">
                 <Card>
                  <CardHeader>
                    <CardTitle>Notificações</CardTitle>
                    <CardDescription>Escolha como você quer ser notificado.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>E-mails de Novos Leads</Label>
                      </div>
                      <Switch checked={true} />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Alertas de Vencimento de Tarefas</Label>
                      </div>
                      <Switch checked={true} />
                    </div>
                     <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Confirmação de Pagamentos</Label>
                      </div>
                      <Switch checked={true} />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </motion.div>
          </div>
        </div>
      </Tabs>
    </div>
  );
}
