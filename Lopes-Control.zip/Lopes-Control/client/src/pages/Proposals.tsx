import { useState } from "react";
import { proposals, clients } from "@/services/data";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, FileText, Send, Download, MoreHorizontal, Calendar, DollarSign } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Proposals() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredProposals = proposals.filter(
    (prop) =>
      prop.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      clients.find(c => c.id === prop.clientId)?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "accepted": return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
      case "rejected": return "bg-red-500/10 text-red-500 border-red-500/20";
      case "sent": return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "draft": return "bg-muted text-muted-foreground border-border";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Propostas</h1>
          <p className="text-muted-foreground">Crie e envie orçamentos profissionais.</p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)]">
            <Plus className="w-4 h-4 mr-2" /> Nova Proposta
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4 bg-card/50 p-2 rounded-lg border border-border/50 backdrop-blur-sm">
        <Search className="w-5 h-5 text-muted-foreground ml-2" />
        <Input 
          placeholder="Buscar propostas..." 
          className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {filteredProposals.map((prop) => (
          <motion.div key={prop.id} variants={item}>
            <Card className="group hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    <FileText className="w-5 h-5" />
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem><Send className="w-4 h-4 mr-2" /> Enviar por e-mail</DropdownMenuItem>
                      <DropdownMenuItem><Download className="w-4 h-4 mr-2" /> Baixar PDF</DropdownMenuItem>
                      <DropdownMenuItem>Editar</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive">Excluir</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="mb-4">
                  <h3 className="font-bold text-lg mb-1">{prop.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {clients.find(c => c.id === prop.clientId)?.name}
                  </p>
                </div>

                <div className="flex items-center gap-2 mb-6">
                  <Badge variant="outline" className={cn("uppercase text-[10px] font-bold tracking-wider", getStatusColor(prop.status))}>
                    {prop.status === "sent" ? "Enviada" : prop.status === "draft" ? "Rascunho" : prop.status === "accepted" ? "Aceita" : "Rejeitada"}
                  </Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> {new Date(prop.dateSent).toLocaleDateString('pt-BR')}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div className="flex flex-col">
                    <span className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Valor</span>
                    <span className="text-lg font-mono font-bold flex items-center gap-1">
                      R$ {prop.value.toLocaleString('pt-BR')}
                    </span>
                  </div>
                  <Button size="sm" variant="outline" className="opacity-0 group-hover:opacity-100 transition-opacity">
                    Detalhes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
