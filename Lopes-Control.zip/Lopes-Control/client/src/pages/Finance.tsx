import { invoices, expenses, kpis } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Download, Filter, MoreHorizontal, Wallet, PieChart as PieChartIcon, Activity } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

// Fake cashflow data
const cashflowData = [
  { name: 'Jan', income: 4000, expense: 2400 },
  { name: 'Fev', income: 3000, expense: 1398 },
  { name: 'Mar', income: 2000, expense: 9800 },
  { name: 'Abr', income: 2780, expense: 3908 },
  { name: 'Mai', income: 1890, expense: 4800 },
  { name: 'Jun', income: 2390, expense: 3800 },
  { name: 'Jul', income: 3490, expense: 4300 },
];

export default function Finance() {
  const totalIncome = invoices
    .filter(i => i.status === "paid")
    .reduce((acc, curr) => acc + curr.amount, 0);
  
  const totalPending = invoices
    .filter(i => i.status === "pending" || i.status === "overdue")
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Financeiro</h1>
          <p className="text-muted-foreground">Controle de receitas, despesas e fluxo de caixa.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="border-border/60"><Download className="w-4 h-4 mr-2" /> Relatório</Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)] hover:scale-105 transition-transform">
            <Plus className="w-4 h-4 mr-2" /> Nova Transação
          </Button>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
      >
        <motion.div variants={item}>
          <Card className="bg-gradient-to-br from-emerald-500/10 to-transparent border-emerald-500/20 overflow-hidden relative">
            <div className="absolute right-0 top-0 p-4 opacity-10">
               <TrendingUp className="w-24 h-24 text-emerald-500" />
            </div>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-emerald-500/20 rounded-xl text-emerald-500">
                  <Wallet className="w-6 h-6" />
                </div>
                <Badge variant="outline" className="border-emerald-500/30 text-emerald-500 bg-emerald-500/10 flex items-center gap-1">
                   <ArrowUpRight className="w-3 h-3" /> +12%
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground font-bold uppercase tracking-wider">Receita Recebida</p>
              <h3 className="text-3xl font-bold font-heading mt-1">R$ {totalIncome.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="bg-gradient-to-br from-blue-500/10 to-transparent border-blue-500/20 overflow-hidden relative">
            <div className="absolute right-0 top-0 p-4 opacity-10">
               <Activity className="w-24 h-24 text-blue-500" />
            </div>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-blue-500/20 rounded-xl text-blue-500">
                  <PieChartIcon className="w-6 h-6" />
                </div>
                <Badge variant="outline" className="border-blue-500/30 text-blue-500 bg-blue-500/10">Pendente</Badge>
              </div>
              <p className="text-sm text-muted-foreground font-bold uppercase tracking-wider">A Receber</p>
              <h3 className="text-3xl font-bold font-heading mt-1">R$ {totalPending.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="bg-gradient-to-br from-red-500/10 to-transparent border-red-500/20 overflow-hidden relative">
            <div className="absolute right-0 top-0 p-4 opacity-10">
               <TrendingDown className="w-24 h-24 text-red-500" />
            </div>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-red-500/20 rounded-xl text-red-500">
                  <TrendingDown className="w-6 h-6" />
                </div>
                <Badge variant="outline" className="border-red-500/30 text-red-500 bg-red-500/10 flex items-center gap-1">
                  <ArrowDownRight className="w-3 h-3" /> -5%
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground font-bold uppercase tracking-wider">Despesas</p>
              <h3 className="text-3xl font-bold font-heading mt-1">R$ {totalExpenses.toLocaleString('pt-BR')}</h3>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      {/* Cashflow Chart */}
      <motion.div variants={item}>
        <Card className="border-border/60 bg-card/40 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Fluxo de Caixa</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
             <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={cashflowData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `R$${value}`} />
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} opacity={0.4} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px', color: 'hsl(var(--foreground))' }}
                    itemStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                  <Area type="monotone" dataKey="income" stroke="#10b981" fillOpacity={1} fill="url(#colorIncome)" strokeWidth={2} name="Receitas" />
                  <Area type="monotone" dataKey="expense" stroke="#ef4444" fillOpacity={1} fill="url(#colorExpense)" strokeWidth={2} name="Despesas" />
                </AreaChart>
             </ResponsiveContainer>
          </CardContent>
        </Card>
      </motion.div>

      <Tabs defaultValue="invoices" className="w-full">
        <div className="flex items-center justify-between mb-4">
          <TabsList className="bg-muted/50 border border-border/50">
            <TabsTrigger value="invoices">Faturas</TabsTrigger>
            <TabsTrigger value="expenses">Despesas</TabsTrigger>
          </TabsList>
          <Button variant="ghost" size="sm" className="gap-2">
            <Filter className="w-4 h-4" /> Filtros
          </Button>
        </div>

        <TabsContent value="invoices" className="space-y-4">
          <Card className="border-border/60 bg-card/40 backdrop-blur-sm overflow-hidden">
            <CardContent className="p-0">
              <div className="">
                <table className="w-full text-sm">
                  <thead className="bg-muted/30 text-muted-foreground font-medium uppercase text-xs">
                    <tr className="border-b border-border/50">
                      <th className="px-6 py-4 text-left">Descrição</th>
                      <th className="px-6 py-4 text-left">Cliente</th>
                      <th className="px-6 py-4 text-left">Data</th>
                      <th className="px-6 py-4 text-left">Valor</th>
                      <th className="px-6 py-4 text-left">Status</th>
                      <th className="px-6 py-4 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoices.map((inv) => (
                      <motion.tr 
                        key={inv.id} 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors group"
                      >
                        <td className="px-6 py-4 font-bold">{inv.description}</td>
                        <td className="px-6 py-4 text-muted-foreground">Cliente #{inv.clientId}</td>
                        <td className="px-6 py-4 text-muted-foreground">{new Date(inv.date).toLocaleDateString('pt-BR')}</td>
                        <td className="px-6 py-4 font-mono font-bold">R$ {inv.amount.toLocaleString('pt-BR')}</td>
                        <td className="px-6 py-4">
                          <Badge variant="outline" className={cn(
                            "uppercase text-[10px] font-bold tracking-wider py-1 px-2 border-0",
                            inv.status === "paid" && "bg-emerald-500/10 text-emerald-500 ring-1 ring-emerald-500/20",
                            inv.status === "pending" && "bg-yellow-500/10 text-yellow-500 ring-1 ring-yellow-500/20",
                            inv.status === "overdue" && "bg-red-500/10 text-red-500 ring-1 ring-red-500/20",
                          )}>
                            {inv.status === "paid" ? "Pago" : inv.status === "pending" ? "Pendente" : "Atrasado"}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expenses" className="space-y-4">
          <Card className="border-border/60 bg-card/40 backdrop-blur-sm overflow-hidden">
            <CardContent className="p-0">
              <div className="">
                <table className="w-full text-sm">
                  <thead className="bg-muted/30 text-muted-foreground font-medium uppercase text-xs">
                    <tr className="border-b border-border/50">
                      <th className="px-6 py-4 text-left">Descrição</th>
                      <th className="px-6 py-4 text-left">Categoria</th>
                      <th className="px-6 py-4 text-left">Data</th>
                      <th className="px-6 py-4 text-left">Valor</th>
                      <th className="px-6 py-4 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {expenses.map((exp) => (
                      <motion.tr 
                        key={exp.id} 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors group"
                      >
                        <td className="px-6 py-4 font-bold">{exp.description}</td>
                        <td className="px-6 py-4 capitalize">
                          <Badge variant="secondary" className="font-normal">{exp.category}</Badge>
                        </td>
                        <td className="px-6 py-4 text-muted-foreground">{new Date(exp.date).toLocaleDateString('pt-BR')}</td>
                        <td className="px-6 py-4 font-mono font-bold text-red-400">- R$ {exp.amount.toLocaleString('pt-BR')}</td>
                        <td className="px-6 py-4 text-right">
                          <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
