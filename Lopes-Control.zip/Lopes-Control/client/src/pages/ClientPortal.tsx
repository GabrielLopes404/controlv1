import { useState } from "react";
import { useParams } from "wouter";
import { clients, projects, invoices } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, CheckCircle2, Clock, FileText, MessageSquare, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

// This simulates what the CLIENT sees
export default function ClientPortal() {
  // Mocking a client view for "TechFlow" (ID 1)
  const client = clients[0];
  const clientProjects = projects.filter(p => p.clientId === client.id);
  const clientInvoices = invoices.filter(i => i.clientId === client.id);
  
  return (
    <div className="min-h-screen bg-background font-sans">
      {/* Client Header */}
      <header className="h-20 border-b border-border bg-card/50 backdrop-blur-md flex items-center justify-between px-6 lg:px-12 sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-sm flex items-center justify-center font-heading font-bold text-2xl text-primary-foreground">
            L
          </div>
          <div className="h-8 w-px bg-border mx-2"></div>
          <h2 className="text-lg font-bold">Portal do Cliente</h2>
        </div>
        <div className="flex items-center gap-4">
           <div className="text-right hidden sm:block">
             <p className="text-sm font-bold">{client.name}</p>
             <p className="text-xs text-muted-foreground">{client.company}</p>
           </div>
           <div className="w-10 h-10 rounded-full bg-muted border border-border overflow-hidden">
             <img src={client.avatar} alt={client.name} className="w-full h-full object-cover" />
           </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 lg:p-12 space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-heading font-bold">Olá, {client.name.split(' ')[0]}! 👋</h1>
            <p className="text-muted-foreground">Acompanhe aqui o andamento dos seus projetos.</p>
          </div>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)]">
            <MessageSquare className="w-4 h-4 mr-2" /> Falar com Designer
          </Button>
        </div>

        {/* Active Projects */}
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary" /> Projetos em Andamento
          </h2>
          <div className="grid gap-6">
            {clientProjects.filter(p => p.status === 'in_progress').map(project => (
              <Card key={project.id} className="overflow-hidden border-l-4 border-l-primary">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between gap-6 mb-6">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-2xl font-bold">{project.title}</h3>
                        <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20">Em Andamento</Badge>
                      </div>
                      <p className="text-muted-foreground">Previsão de entrega: <span className="text-foreground font-medium">{new Date(project.deadline).toLocaleDateString('pt-BR')}</span></p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">Status Global</p>
                      <p className="text-3xl font-heading font-bold text-primary">{project.progress}%</p>
                    </div>
                  </div>

                  <div className="space-y-2 mb-6">
                    <Progress value={project.progress} className="h-3" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Início</span>
                      <span>Entrega</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-muted/30 p-4 rounded-lg border border-border">
                       <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
                         <FileText className="w-4 h-4 text-primary" /> Arquivos Recentes
                       </h4>
                       <ul className="space-y-2 text-sm">
                         <li className="flex justify-between items-center text-muted-foreground hover:text-foreground cursor-pointer">
                           <span>Wireframes v2.pdf</span>
                           <Download className="w-3 h-3" />
                         </li>
                         <li className="flex justify-between items-center text-muted-foreground hover:text-foreground cursor-pointer">
                           <span>Moodboard.png</span>
                           <Download className="w-3 h-3" />
                         </li>
                       </ul>
                    </div>
                     <div className="bg-muted/30 p-4 rounded-lg border border-border">
                       <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
                         <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Entregas Aprovadas
                       </h4>
                       <ul className="space-y-2 text-sm">
                         <li className="flex items-center gap-2 text-muted-foreground">
                           <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Briefing
                         </li>
                         <li className="flex items-center gap-2 text-muted-foreground">
                           <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Estrutura de Navegação
                         </li>
                       </ul>
                    </div>
                    <div className="bg-muted/30 p-4 rounded-lg border border-border flex flex-col justify-center items-center text-center gap-2">
                        <p className="text-sm text-muted-foreground">Precisa aprovar algo?</p>
                        <Button size="sm" variant="outline" className="w-full">Ver Aprovações Pendentes</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Finance */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
           <div>
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" /> Faturas e Pagamentos
              </h2>
              <Card>
                <CardContent className="p-0">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-muted/50 text-muted-foreground font-medium">
                      <tr>
                        <th className="px-4 py-3">Descrição</th>
                        <th className="px-4 py-3">Valor</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3 text-right">Ação</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {clientInvoices.map(inv => (
                        <tr key={inv.id}>
                          <td className="px-4 py-3 font-medium">{inv.description}</td>
                          <td className="px-4 py-3">R$ {inv.amount.toLocaleString('pt-BR')}</td>
                          <td className="px-4 py-3">
                            <Badge variant="outline" className={cn(
                              "text-[10px] uppercase",
                              inv.status === 'paid' ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/10" : "text-yellow-500 border-yellow-500/20 bg-yellow-500/10"
                            )}>{inv.status === 'paid' ? 'Pago' : 'Pendente'}</Badge>
                          </td>
                          <td className="px-4 py-3 text-right">
                            {inv.status === 'pending' ? (
                              <Button size="sm" className="h-7 text-xs bg-emerald-600 hover:bg-emerald-700">Pagar</Button>
                            ) : (
                              <Button size="sm" variant="ghost" className="h-7 text-xs"><Download className="w-3 h-3" /></Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </CardContent>
              </Card>
           </div>
           
           <div>
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-primary" /> Histórico de Projetos
              </h2>
              <div className="space-y-4">
                 {clientProjects.filter(p => p.status === 'completed').map(project => (
                   <Card key={project.id} className="opacity-80 hover:opacity-100 transition-opacity">
                     <CardContent className="p-4 flex items-center justify-between">
                       <div>
                         <h4 className="font-bold">{project.title}</h4>
                         <p className="text-xs text-muted-foreground">Entregue em: {new Date(project.deadline).toLocaleDateString('pt-BR')}</p>
                       </div>
                       <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-500">Concluído</Badge>
                     </CardContent>
                   </Card>
                 ))}
                 {clientProjects.filter(p => p.status === 'completed').length === 0 && (
                   <div className="p-8 text-center border border-dashed border-border rounded-lg text-muted-foreground">
                     Nenhum projeto concluído ainda.
                   </div>
                 )}
              </div>
           </div>
        </section>
      </main>
    </div>
  );
}
