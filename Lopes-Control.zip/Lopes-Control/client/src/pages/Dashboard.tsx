import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { kpis, projects, tasks, invoices } from "@/services/data";
import { ArrowUpRight, ArrowDownRight, Clock, CheckCircle2, AlertCircle, MoreHorizontal, FileText, Users, CreditCard, TrendingUp, Activity, DollarSign } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

// Fake data for sparklines
const sparklineData = [
  { value: 10 }, { value: 15 }, { value: 12 }, { value: 20 }, { value: 18 }, { value: 25 }, { value: 22 }
];

export default function Dashboard() {
  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-8"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-heading font-bold text-foreground tracking-tight">
            Dashboard
            <span className="text-primary">.</span>
          </h1>
          <p className="text-muted-foreground mt-1 text-lg">Visão geral do seu império criativo.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="h-10 border-primary/20 hover:border-primary hover:bg-primary/5 hover:text-primary transition-all">
            <Activity className="w-4 h-4 mr-2" /> Relatório Rápido
          </Button>
          <Button className="h-10 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-white shadow-[0_0_25px_rgba(255,0,170,0.4)] border-0 transition-all hover:scale-105">
            <TrendingUp className="w-4 h-4 mr-2" /> Novo Projeto
          </Button>
        </div>
      </div>

      {/* KPI Section with "Big Tech" Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, i) => (
          <motion.div key={i} variants={item} whileHover={{ y: -5 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-border/60 bg-card/40 backdrop-blur-xl hover:border-primary/50 transition-all duration-500 group shadow-lg">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                 {i === 0 ? <DollarSign className="w-20 h-20 text-primary" /> : 
                  i === 1 ? <BriefcaseIcon className="w-20 h-20 text-blue-500" /> :
                  i === 2 ? <Clock className="w-20 h-20 text-purple-500" /> :
                  <FileText className="w-20 h-20 text-yellow-500" />
                 }
              </div>
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className={cn(
                    "p-2 rounded-lg",
                    i === 0 ? "bg-primary/10 text-primary" : 
                    i === 1 ? "bg-blue-500/10 text-blue-500" :
                    i === 2 ? "bg-purple-500/10 text-purple-500" :
                    "bg-yellow-500/10 text-yellow-500"
                  )}>
                    {i === 0 ? <DollarSign className="w-5 h-5" /> : 
                     i === 1 ? <Users className="w-5 h-5" /> :
                     i === 2 ? <Clock className="w-5 h-5" /> :
                     <FileText className="w-5 h-5" />
                    }
                  </div>
                  <Badge variant="outline" className={cn(
                    "border-0 bg-opacity-10",
                    kpi.trend === "up" ? "bg-emerald-500 text-emerald-500" : "bg-red-500 text-red-500"
                  )}>
                    {kpi.change > 0 ? "+" : ""}{kpi.change}%
                  </Badge>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-widest text-[10px]">{kpi.label}</p>
                  <h3 className="text-3xl font-bold font-heading tracking-tight">{kpi.value}</h3>
                </div>

                {/* Mini Sparkline */}
                <div className="h-10 w-full mt-4 opacity-50 group-hover:opacity-100 transition-opacity">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={sparklineData}>
                      <defs>
                        <linearGradient id={`colorKv${i}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={i===0?"#FF00AA":i===1?"#3b82f6":i===2?"#a855f7":"#eab308"} stopOpacity={0.3}/>
                          <stop offset="95%" stopColor={i===0?"#FF00AA":i===1?"#3b82f6":i===2?"#a855f7":"#eab308"} stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <Area 
                        type="monotone" 
                        dataKey="value" 
                        stroke={i===0?"#FF00AA":i===1?"#3b82f6":i===2?"#a855f7":"#eab308"} 
                        fillOpacity={1} 
                        fill={`url(#colorKv${i})`} 
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content - Projects & Finance */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Recent Projects Table - Enhanced */}
          <motion.div variants={item}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-heading font-bold flex items-center gap-2">
                <Activity className="w-6 h-6 text-primary" /> Projetos em Foco
              </h2>
              <Button variant="ghost" className="text-sm text-primary hover:bg-primary/10">Ver todos os projetos &rarr;</Button>
            </div>
            <Card className="border-border/60 bg-card/40 backdrop-blur-md overflow-hidden shadow-lg">
               <div className="overflow-x-auto">
                 <table className="w-full text-sm text-left">
                    <thead className="bg-muted/40 text-muted-foreground uppercase text-xs font-bold tracking-wider">
                      <tr>
                        <th className="px-6 py-4">Projeto</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4">Entrega</th>
                        <th className="px-6 py-4 text-right">Progresso</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/50">
                      {projects.slice(0, 4).map((project) => (
                        <tr key={project.id} className="hover:bg-muted/20 transition-colors group cursor-pointer">
                          <td className="px-6 py-4">
                            <div className="font-bold text-base group-hover:text-primary transition-colors">{project.title}</div>
                            <div className="text-xs text-muted-foreground mt-0.5">TechFlow Inc.</div>
                          </td>
                          <td className="px-6 py-4">
                             <Badge variant="outline" className={cn(
                                "uppercase text-[10px] font-bold tracking-wider py-1 px-2 border-0 bg-opacity-10",
                                project.status === "in_progress" && "bg-blue-500 text-blue-500 ring-1 ring-blue-500/20",
                                project.status === "completed" && "bg-emerald-500 text-emerald-500 ring-1 ring-emerald-500/20",
                                project.status === "proposal" && "bg-yellow-500 text-yellow-500 ring-1 ring-yellow-500/20",
                              )}>
                                {project.status.replace("_", " ")}
                              </Badge>
                          </td>
                          <td className="px-6 py-4 font-medium text-muted-foreground">
                             {new Date(project.deadline).toLocaleDateString('pt-BR')}
                          </td>
                          <td className="px-6 py-4 text-right w-48">
                             <div className="flex flex-col items-end gap-1">
                               <span className="font-bold text-xs">{project.progress}%</span>
                               <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                                 <div 
                                   className="h-full bg-gradient-to-r from-primary to-purple-600 rounded-full transition-all duration-1000 ease-out" 
                                   style={{ width: `${project.progress}%` }} 
                                 />
                               </div>
                             </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                 </table>
               </div>
            </Card>
          </motion.div>

          {/* Finance Visual - Enhanced */}
          <motion.div variants={item}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-heading font-bold flex items-center gap-2">
                <CreditCard className="w-6 h-6 text-emerald-500" /> Últimas Movimentações
              </h2>
              <Button variant="ghost" className="text-sm text-primary hover:bg-primary/10">Gestão Financeira &rarr;</Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {invoices.slice(0, 2).map((inv, idx) => (
                 <Card key={inv.id} className="border-l-4 border-l-emerald-500 bg-card/40 backdrop-blur hover:bg-muted/20 transition-colors cursor-pointer group">
                    <CardContent className="p-5 flex justify-between items-center">
                       <div>
                          <p className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-1">Receita Confirmada</p>
                          <h4 className="font-bold text-lg group-hover:text-emerald-500 transition-colors">{inv.description}</h4>
                          <p className="text-xs text-muted-foreground mt-1">{new Date(inv.date).toLocaleDateString('pt-BR')}</p>
                       </div>
                       <div className="text-right">
                          <p className="text-xl font-mono font-bold">R$ {inv.amount.toLocaleString('pt-BR')}</p>
                          <Badge variant="outline" className="mt-1 border-emerald-500/30 text-emerald-500 bg-emerald-500/5">PAGO</Badge>
                       </div>
                    </CardContent>
                 </Card>
               ))}
            </div>
          </motion.div>

        </div>

        {/* Sidebar Column - Tasks & Quick Actions */}
        <div className="space-y-8">
          
          {/* Tasks Widget - Enhanced */}
          <motion.div variants={item}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-heading font-bold">Prioridades</h2>
              <Badge className="bg-primary text-white hover:bg-primary">Hoje: 4</Badge>
            </div>
            <Card className="bg-card/40 backdrop-blur border-border/60 shadow-lg">
              <CardContent className="p-0">
                {tasks.slice(0, 5).map((task, idx) => (
                  <div key={task.id} className={cn(
                    "flex items-start gap-3 p-4 border-b border-border/50 hover:bg-primary/5 transition-colors cursor-pointer group",
                    idx === tasks.length - 1 && "border-0"
                  )}>
                    <div className="mt-1">
                      <div className={cn(
                        "w-5 h-5 rounded border-2 flex items-center justify-center cursor-pointer transition-all duration-300",
                        task.status === "done" 
                          ? "bg-primary border-primary text-primary-foreground" 
                          : "border-muted-foreground/30 group-hover:border-primary"
                      )}>
                        {task.status === "done" && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                    <div className="flex-1">
                      <p className={cn(
                        "text-sm font-medium transition-all group-hover:text-primary",
                        task.status === "done" && "text-muted-foreground line-through"
                      )}>
                        {task.title}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <Badge variant="secondary" className={cn(
                          "text-[9px] h-4 px-1 uppercase tracking-wider font-bold border-0",
                          task.priority === "high" && "bg-red-500/10 text-red-500",
                          task.priority === "medium" && "bg-yellow-500/10 text-yellow-500",
                        )}>
                          {task.priority}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {new Date(task.dueDate).toLocaleDateString('pt-BR', {day: '2-digit', month: 'short'})}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Quick Actions - Enhanced */}
          <motion.div variants={item}>
             <h2 className="text-xl font-heading font-bold mb-4">Acesso Rápido</h2>
             <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: FileText, label: "Nova Proposta", color: "text-blue-500" },
                  { icon: Users, label: "Novo Cliente", color: "text-emerald-500" },
                  { icon: CreditCard, label: "Nova Fatura", color: "text-purple-500" },
                  { icon: Clock, label: "Timetracker", color: "text-yellow-500" }
                ].map((action, i) => (
                  <Button 
                    key={i}
                    variant="outline" 
                    className="h-24 flex flex-col gap-3 border-border/60 hover:border-primary hover:bg-primary/5 hover:scale-[1.02] transition-all duration-300 group"
                  >
                    <div className={cn("p-2 rounded-full bg-muted group-hover:bg-background transition-colors", action.color)}>
                      <action.icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-bold group-hover:text-primary transition-colors">{action.label}</span>
                  </Button>
                ))}
             </div>
          </motion.div>

        </div>
      </div>
    </motion.div>
  );
}

// Simple icon component for mapping
function BriefcaseIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="14" x="2" y="7" rx="2" ry="2" />
      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
    </svg>
  )
}
