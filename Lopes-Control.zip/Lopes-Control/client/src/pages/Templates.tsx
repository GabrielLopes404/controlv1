import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, Copy, Check, Star, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

const templates = [
  {
    id: 1,
    title: "Proposta Comercial Premium",
    category: "Propostas",
    description: "Template completo com apresentação, escopo, cronograma e investimento.",
    popular: true,
  },
  {
    id: 2,
    title: "Contrato de Prestação de Serviços",
    category: "Jurídico",
    description: "Cláusulas essenciais para proteger seu trabalho e direitos autorais.",
    popular: true,
  },
  {
    id: 3,
    title: "Briefing de Identidade Visual",
    category: "Design",
    description: "Perguntas estratégicas para extrair a essência da marca do cliente.",
    popular: false,
  },
  {
    id: 4,
    title: "Relatório de Performance Mensal",
    category: "Relatórios",
    description: "Modelo visual para apresentar resultados e métricas para o cliente.",
    popular: false,
  },
  {
    id: 5,
    title: "Checklist de Lançamento de Site",
    category: "Processos",
    description: "Lista de verificação para garantir que nada seja esquecido antes do go-live.",
    popular: false,
  },
  {
    id: 6,
    title: "E-mail de Cobrança Amigável",
    category: "E-mails",
    description: "Script pronto para cobrar clientes atrasados sem perder a elegância.",
    popular: true,
  }
];

export default function Templates() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Templates</h1>
          <p className="text-muted-foreground">Modelos prontos para agilizar seu trabalho.</p>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2">
        <Button variant="secondary" className="rounded-full">Todos</Button>
        <Button variant="ghost" className="rounded-full">Propostas</Button>
        <Button variant="ghost" className="rounded-full">Contratos</Button>
        <Button variant="ghost" className="rounded-full">E-mails</Button>
        <Button variant="ghost" className="rounded-full">Briefings</Button>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {templates.map((template) => (
          <motion.div key={template.id} variants={item}>
            <Card className="group hover:border-primary/50 transition-all duration-300 h-full flex flex-col">
              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="secondary" className="font-normal">{template.category}</Badge>
                  {template.popular && (
                    <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20 gap-1">
                      <Star className="w-3 h-3 fill-current" /> Popular
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-xl">{template.title}</CardTitle>
                <CardDescription className="line-clamp-2">{template.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="w-full h-32 bg-muted/30 rounded-lg flex items-center justify-center border border-dashed border-border group-hover:bg-primary/5 transition-colors">
                  <FileText className="w-10 h-10 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </CardContent>
              <CardFooter className="gap-2">
                <Button className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_15px_rgba(255,0,170,0.2)]">
                  Usar Modelo
                </Button>
                <Button variant="outline" size="icon">
                  <Download className="w-4 h-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
