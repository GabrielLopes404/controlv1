import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { tasks, projects } from "@/services/data";

const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const currentDate = new Date();
const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
const currentYear = currentDate.getFullYear();

// Mock calendar grid generation
const generateCalendarDays = () => {
  const daysArray = [];
  // Previous month padding
  for (let i = 0; i < 3; i++) daysArray.push({ day: 28 + i, type: "prev" });
  // Current month
  for (let i = 1; i <= 30; i++) daysArray.push({ day: i, type: "current" });
  // Next month padding
  for (let i = 1; i <= 9; i++) daysArray.push({ day: i, type: "next" });
  return daysArray;
};

const calendarDays = generateCalendarDays();

export default function Calendar() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Calendário</h1>
          <p className="text-muted-foreground">Visualize seus prazos e entregas.</p>
        </div>
        <div className="flex gap-2">
           <Button variant="outline" className="gap-2">
             <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Google_Calendar_icon_%282020%29.svg" className="w-4 h-4" alt="Google" />
             Sincronizar Google
           </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)]">
            <Plus className="w-4 h-4 mr-2" /> Novo Evento
          </Button>
        </div>
      </div>

      <Card className="h-full flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between py-4 border-b border-border">
          <div className="flex items-center gap-4">
            <h2 className="text-2xl font-bold font-heading capitalize">{currentMonth} {currentYear}</h2>
            <div className="flex items-center border border-border rounded-md">
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-none border-r border-border"><ChevronLeft className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-none"><ChevronRight className="w-4 h-4" /></Button>
            </div>
          </div>
          <div className="flex gap-2">
             <Button variant="secondary" size="sm">Mês</Button>
             <Button variant="ghost" size="sm">Semana</Button>
             <Button variant="ghost" size="sm">Dia</Button>
          </div>
        </CardHeader>
        <CardContent className="p-0 flex-1">
          <div className="grid grid-cols-7 border-b border-border">
            {days.map(day => (
              <div key={day} className="py-2 text-center text-sm font-medium text-muted-foreground border-r border-border last:border-r-0">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 grid-rows-6 h-[600px]">
            {calendarDays.map((date, index) => {
              // Find tasks for this "mock" date mapping
              // In a real app, match actual dates. Here we just distribute tasks randomly for visual effect
              const dayTasks = tasks.filter((_, i) => (i % 30) + 1 === date.day && date.type === "current");
              
              return (
                <div 
                  key={index} 
                  className={cn(
                    "border-r border-b border-border p-2 min-h-[100px] hover:bg-muted/20 transition-colors relative group",
                    date.type !== "current" && "bg-muted/10 text-muted-foreground/50",
                    index % 7 === 6 && "border-r-0" // Remove right border for last column
                  )}
                >
                  <span className={cn(
                    "text-sm font-medium w-6 h-6 flex items-center justify-center rounded-full mb-1",
                    date.day === currentDate.getDate() && date.type === "current" ? "bg-primary text-primary-foreground" : ""
                  )}>
                    {date.day}
                  </span>
                  
                  <div className="space-y-1">
                    {dayTasks.map(task => (
                      <div 
                        key={task.id} 
                        className={cn(
                          "text-[10px] px-1.5 py-1 rounded truncate cursor-pointer border-l-2 hover:opacity-80",
                          task.priority === "high" ? "bg-red-500/10 border-red-500 text-red-500" :
                          task.priority === "medium" ? "bg-yellow-500/10 border-yellow-500 text-yellow-500" :
                          "bg-blue-500/10 border-blue-500 text-blue-500"
                        )}
                      >
                        {task.title}
                      </div>
                    ))}
                    {date.day === 15 && date.type === "current" && (
                       <div className="text-[10px] px-1.5 py-1 rounded truncate cursor-pointer border-l-2 bg-purple-500/10 border-purple-500 text-purple-500">
                         Entrega Final - TechFlow
                       </div>
                    )}
                  </div>
                  
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute bottom-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
