import { useState } from "react";
import { clients, projects } from "@/services/data";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, MoreHorizontal, Mail, Phone, Building, LayoutGrid, Kanban, ArrowRight, Wallet, Star } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Clients() {
  const [searchTerm, setSearchTerm] = useState("");
  const [view, setView] = useState<"grid" | "pipeline">("grid");

  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.company.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Clientes</h1>
          <p className="text-muted-foreground">Gerencie sua carteira e funil de vendas.</p>
        </div>
        <div className="flex gap-2">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(255,0,170,0.3)] hover:scale-105 transition-transform">
            <Plus className="w-4 h-4 mr-2" /> Novo Cliente
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between bg-card/40 p-2 rounded-xl border border-border/50 backdrop-blur-sm sticky top-20 z-10 shadow-sm gap-4">
        <div className="flex items-center gap-2 flex-1">
          <Search className="w-5 h-5 text-muted-foreground ml-2" />
          <Input 
            placeholder="Buscar por nome ou empresa..." 
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="bg-muted/50 p-1 rounded-lg flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setView("grid")} 
            className={cn("h-8 px-3 rounded-md transition-all text-xs font-medium", view === "grid" && "bg-background shadow-sm text-foreground")}
          >
             <LayoutGrid className="w-4 h-4 mr-2" /> Grade
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setView("pipeline")} 
            className={cn("h-8 px-3 rounded-md transition-all text-xs font-medium", view === "pipeline" && "bg-background shadow-sm text-foreground")}
          >
             <Kanban className="w-4 h-4 mr-2" /> Pipeline
          </Button>
        </div>
      </div>

      {view === "grid" ? (
        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredClients.map((client) => (
            <motion.div key={client.id} variants={item}>
              <Card className="group hover:border-primary/50 transition-all duration-300 bg-card/40 backdrop-blur border-border/60 hover:shadow-lg hover:shadow-primary/5 overflow-hidden">
                <div className="h-24 bg-gradient-to-r from-muted to-muted/50 relative">
                   <div className="absolute top-4 right-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0 hover:bg-black/10 text-muted-foreground">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                          <DropdownMenuItem>Editar</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive">Excluir</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                   </div>
                </div>
                
                <CardContent className="pt-0 relative px-6 pb-6">
                  <div className="flex justify-between items-end -mt-10 mb-4">
                     <Avatar className="h-20 w-20 border-4 border-card shadow-md">
                        <AvatarImage src={client.avatar} alt={client.name} />
                        <AvatarFallback className="text-xl bg-primary/10 text-primary font-heading font-bold">{client.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <Badge variant="outline" className={cn(
                        "uppercase text-[10px] font-bold tracking-wider mb-2",
                        client.status === "active" && "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
                        client.status === "lead" && "bg-blue-500/10 text-blue-500 border-blue-500/20",
                        client.status === "inactive" && "bg-muted text-muted-foreground",
                      )}>
                        {client.status === "active" ? "Ativo" : client.status === "lead" ? "Lead" : "Inativo"}
                      </Badge>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-xl font-bold font-heading leading-tight">{client.name}</h3>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                      <Building className="w-3.5 h-3.5" />
                      {client.company}
                    </div>
                  </div>

                  <div className="grid gap-3 mb-6">
                    <div className="flex items-center text-sm text-muted-foreground bg-muted/30 p-2 rounded-lg transition-colors hover:bg-muted/50 hover:text-foreground">
                      <Mail className="w-4 h-4 mr-3 text-primary/70" />
                      {client.email}
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground bg-muted/30 p-2 rounded-lg transition-colors hover:bg-muted/50 hover:text-foreground">
                      <Phone className="w-4 h-4 mr-3 text-primary/70" />
                      {client.phone}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between border-t border-border/50 pt-4">
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider mb-1">LTV (Total)</p>
                      <p className="font-mono font-bold text-foreground flex items-center gap-1">
                        <Wallet className="w-3.5 h-3.5 text-emerald-500" />
                        R$ {client.totalRevenue.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider mb-1">Projetos</p>
                       <p className="font-bold text-foreground">{client.projectsCount}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-muted/20 p-4 border-t border-border/50">
                   <Button variant="ghost" className="w-full text-xs font-bold hover:bg-primary hover:text-white transition-all group">
                     Ver Perfil Completo <ArrowRight className="w-3 h-3 ml-2 group-hover:translate-x-1 transition-transform" />
                   </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 h-[calc(100vh-220px)] overflow-x-auto pb-4">
           {['Lead', 'Contacted', 'Proposal', 'Closed'].map((stage) => (
             <div key={stage} className="bg-muted/20 rounded-xl border border-border/50 p-4 flex flex-col min-w-[280px]">
                <h3 className="font-heading font-bold text-sm uppercase tracking-wider mb-4 flex justify-between items-center">
                  {stage}
                  <Badge variant="secondary" className="text-[10px]">{Math.floor(Math.random() * 5)}</Badge>
                </h3>
                {/* Placeholder pipeline cards */}
                <div className="space-y-3">
                   {[1, 2].map((i) => (
                     <Card key={i} className="cursor-grab hover:border-primary/50 shadow-sm">
                        <CardContent className="p-3">
                           <div className="flex justify-between mb-2">
                             <Badge variant="outline" className="text-[10px]">High Priority</Badge>
                             <MoreHorizontal className="w-3 h-3 text-muted-foreground" />
                           </div>
                           <h4 className="font-bold text-sm mb-1">Empresa Exemplo {i}</h4>
                           <p className="text-xs text-muted-foreground mb-3">R$ 5.000,00</p>
                           <div className="flex items-center gap-2">
                             <Avatar className="w-5 h-5">
                               <AvatarFallback className="text-[9px]">JD</AvatarFallback>
                             </Avatar>
                             <span className="text-[10px] text-muted-foreground">2 dias atrás</span>
                           </div>
                        </CardContent>
                     </Card>
                   ))}
                </div>
             </div>
           ))}
        </div>
      )}
    </div>
  );
}
