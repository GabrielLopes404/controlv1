import { Sidebar, MobileNav } from "./Sidebar";
import { Bell, Search, Menu } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { notifications } from "@/services/data";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const unreadCount = notifications.filter(n => !n.read).length;
  const [readNotifications, setReadNotifications] = useState<string[]>([]);

  const handleMarkAsRead = (id: string) => {
    setReadNotifications([...readNotifications, id]);
  };

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <main className="flex-1 md:ml-64 flex flex-col min-h-screen">
        <header className="h-16 border-b border-border bg-background/50 backdrop-blur-md sticky top-0 z-20 flex items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <MobileNav />
            <div className="relative hidden sm:block w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Buscar clientes, projetos, tarefas..." 
                className="pl-10 bg-muted/50 border-transparent focus:bg-background focus:border-primary transition-all"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-primary hover:bg-primary/10">
                  <Bell className="w-5 h-5" />
                  {(unreadCount > 0) && (
                    <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full animate-pulse"></span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Notificações</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {notifications.map((notif) => (
                  <DropdownMenuItem 
                    key={notif.id} 
                    className={cn(
                      "flex flex-col items-start gap-1 p-3 cursor-pointer",
                      !notif.read && !readNotifications.includes(notif.id) ? "bg-primary/5" : ""
                    )}
                    onClick={() => handleMarkAsRead(notif.id)}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className={cn(
                        "font-semibold text-sm",
                        notif.type === "warning" ? "text-yellow-500" :
                        notif.type === "error" ? "text-red-500" :
                        notif.type === "success" ? "text-emerald-500" : "text-primary"
                      )}>
                        {notif.title}
                      </span>
                      <span className="text-[10px] text-muted-foreground">{notif.date}</span>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-2">{notif.message}</p>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem className="justify-center text-xs text-primary font-medium">
                  Ver todas as notificações
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <div className="flex-1 p-6 md:p-8 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
