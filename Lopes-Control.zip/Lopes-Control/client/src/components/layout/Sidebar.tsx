import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Users,
  Briefcase,
  CheckSquare,
  FileText,
  CreditCard,
  Settings,
  Menu,
  PieChart,
  TrendingUp,
  Target,
  MessageSquare,
  Copy,
  Calendar,
  ExternalLink
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ModeToggle } from "@/components/mode-toggle";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/" },
  { icon: Users, label: "Clientes", href: "/clients" },
  { icon: Briefcase, label: "Projetos", href: "/projects" },
  { icon: CheckSquare, label: "Tarefas", href: "/tasks" },
  { icon: MessageSquare, label: "Chat", href: "/chat" },
  { icon: Calendar, label: "Calendário", href: "/calendar" },
  { icon: FileText, label: "Propostas", href: "/proposals" },
  { icon: Copy, label: "Templates", href: "/templates" },
  { icon: CreditCard, label: "Financeiro", href: "/finance" },
  { icon: TrendingUp, label: "Investimentos", href: "/investments" },
  { icon: Target, label: "Metas", href: "/goals" },
  { icon: PieChart, label: "Relatórios", href: "/reports" },
  { icon: Settings, label: "Configurações", href: "/settings" },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="hidden md:flex flex-col w-64 h-screen border-r border-border bg-sidebar text-sidebar-foreground fixed left-0 top-0 z-30">
      <div className="p-6 flex items-center justify-between">
         {/* Logo placeholder - using text for now, could be image */}
        <div className="flex items-center gap-2">
           <div className="w-8 h-8 bg-primary rounded-sm flex items-center justify-center font-heading font-bold text-xl text-primary-foreground shadow-[0_0_15px_rgba(255,0,170,0.5)]">
            L
           </div>
           <span className="font-heading text-2xl font-bold tracking-wider">LOPES<span className="text-primary">CONTROL</span></span>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-1 py-4 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <a className={cn(
                "flex items-center gap-3 px-4 py-2.5 rounded-md text-sm font-medium transition-all duration-200 group relative overflow-hidden",
                isActive 
                  ? "bg-primary/10 text-primary" 
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              )}>
                {isActive && <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary animate-in fade-in slide-in-from-left-1 duration-300" />}
                <item.icon className={cn("w-4 h-4 transition-colors", isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
                {item.label}
              </a>
            </Link>
          );
        })}
        
        <div className="pt-4 mt-4 border-t border-border/50">
          <p className="px-4 text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Links Externos</p>
          <Link href="/portal">
             <a className="flex items-center gap-3 px-4 py-2.5 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all">
                <ExternalLink className="w-4 h-4" />
                Portal do Cliente
             </a>
          </Link>
        </div>
      </nav>

      <div className="p-4 border-t border-border mt-auto">
        <div className="flex items-center justify-between px-2 mb-4">
           <span className="text-xs font-medium text-muted-foreground">Tema</span>
           <ModeToggle />
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-muted/30 rounded-lg border border-border/50">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center border border-border text-white shadow-lg">
            <span className="font-heading font-bold text-xs">DL</span>
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold text-foreground">Design Lopes</span>
            <span className="text-xs text-muted-foreground">Premium Plan</span>
          </div>
        </div>
      </div>
    </aside>
  );
}

export function MobileNav() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="w-6 h-6" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-72 bg-sidebar border-r border-border p-0">
         <div className="p-6 flex items-center gap-2 border-b border-border">
            <div className="w-8 h-8 bg-primary rounded-sm flex items-center justify-center font-heading font-bold text-xl text-primary-foreground">
              L
            </div>
            <span className="font-heading text-2xl font-bold tracking-wider">LOPES<span className="text-primary">CONTROL</span></span>
          </div>
          <nav className="flex-1 px-4 space-y-2 py-6 overflow-y-auto">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <a 
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-md text-sm font-medium transition-all duration-200",
                      isActive 
                        ? "bg-primary/10 text-primary border-r-2 border-primary" 
                        : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                    )}
                  >
                    <item.icon className={cn("w-5 h-5", isActive ? "text-primary" : "text-muted-foreground")} />
                    {item.label}
                  </a>
                </Link>
              );
            })}
             <Link href="/portal">
                <a className="flex items-center gap-3 px-4 py-3 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all">
                  <ExternalLink className="w-5 h-5" />
                  Portal do Cliente
                </a>
             </Link>
             
             <div className="mt-8 px-4 flex items-center justify-between">
                <span className="text-sm font-medium">Alterar Tema</span>
                <ModeToggle />
             </div>
          </nav>
      </SheetContent>
    </Sheet>
  );
}
