// Types
export interface Client {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  status: "active" | "lead" | "inactive";
  projectsCount: number;
  totalRevenue: number;
  avatar?: string;
}

export interface Project {
  id: string;
  title: string;
  clientId: string;
  status: "proposal" | "in_progress" | "review" | "completed" | "on_hold";
  deadline: string;
  budget: number;
  progress: number;
  tags: string[];
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  status: "todo" | "in_progress" | "review" | "done"; // Added "review"
  priority: "low" | "medium" | "high";
  dueDate: string;
  timeTracked?: number; // in minutes
  isTracking?: boolean;
}

export interface Invoice {
  id: string;
  clientId: string;
  amount: number;
  status: "paid" | "pending" | "overdue";
  date: string;
  dueDate: string;
  description: string;
}

export interface Expense {
  id: string;
  category: "software" | "equipment" | "services" | "other";
  amount: number;
  date: string;
  description: string;
}

export interface Proposal {
  id: string;
  clientId: string;
  title: string;
  value: number;
  status: "draft" | "sent" | "accepted" | "rejected";
  dateSent: string;
  validUntil: string;
  viewCount?: number;
  lastViewed?: string;
}

export interface KPI {
  label: string;
  value: string | number;
  change: number; // percentage
  trend: "up" | "down" | "neutral";
}

export interface Investment {
  id: string;
  ticker: string;
  name: string;
  type: "stock" | "fii" | "fixed" | "crypto";
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  totalInvested: number;
  currentTotal: number;
  profit: number;
  profitPercent: number;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: "info" | "success" | "warning" | "error";
  date: string;
  read: boolean;
  link?: string;
}

export interface Goal {
  id: string;
  title: string;
  current: number;
  target: number;
  unit: string;
  period: "daily" | "weekly" | "monthly";
  type: "revenue" | "tasks" | "clients";
}

// Mock Data
export const clients: Client[] = [
  {
    id: "1",
    name: "Ana Silva",
    company: "TechFlow",
    email: "ana@techflow.com",
    phone: "(11) 99999-1234",
    status: "active",
    projectsCount: 2,
    totalRevenue: 15000,
    avatar: "https://i.pravatar.cc/150?u=1",
  },
  {
    id: "2",
    name: "Carlos Mendes",
    company: "Mendes Advocacia",
    email: "carlos@mendes.adv.br",
    phone: "(11) 98888-5678",
    status: "lead",
    projectsCount: 0,
    totalRevenue: 0,
    avatar: "https://i.pravatar.cc/150?u=2",
  },
  {
    id: "3",
    name: "Studio Vertex",
    company: "Vertex Architecture",
    email: "contact@vertex.arq",
    phone: "(21) 97777-4321",
    status: "active",
    projectsCount: 1,
    totalRevenue: 8500,
  },
  {
    id: "4",
    name: "EcoLife",
    company: "EcoLife Products",
    email: "marketing@ecolife.com",
    phone: "(41) 96666-9876",
    status: "inactive",
    projectsCount: 3,
    totalRevenue: 22000,
  },
];

export const projects: Project[] = [
  {
    id: "101",
    clientId: "1",
    title: "Redesign Website TechFlow",
    status: "in_progress",
    deadline: "2024-06-30",
    budget: 8000,
    progress: 45,
    tags: ["Web Design", "Development"],
  },
  {
    id: "102",
    clientId: "1",
    title: "Identidade Visual TechFlow",
    status: "completed",
    deadline: "2024-04-15",
    budget: 3500,
    progress: 100,
    tags: ["Branding"],
  },
  {
    id: "103",
    clientId: "3",
    title: "Portfolio Fotografia",
    status: "review",
    deadline: "2024-05-20",
    budget: 5000,
    progress: 90,
    tags: ["Web Design"],
  },
  {
    id: "104",
    clientId: "2",
    title: "Site Institucional Mendes",
    status: "proposal",
    deadline: "2024-06-10",
    budget: 4500,
    progress: 0,
    tags: ["Web Design"],
  },
];

export const tasks: Task[] = [
  { id: "t1", projectId: "101", title: "Criar wireframes homepage", status: "done", priority: "high", dueDate: "2024-05-01", timeTracked: 120 },
  { id: "t2", projectId: "101", title: "Desenvolver componentes React", status: "in_progress", priority: "high", dueDate: "2024-05-15", timeTracked: 45, isTracking: true },
  { id: "t3", projectId: "103", title: "Ajustar galeria de fotos", status: "review", priority: "medium", dueDate: "2024-05-18", timeTracked: 30 },
  { id: "t4", projectId: "103", title: "Configurar SEO", status: "todo", priority: "low", dueDate: "2024-05-20" },
  { id: "t5", projectId: "104", title: "Reunião de briefing", status: "done", priority: "high", dueDate: "2024-04-10", timeTracked: 60 },
  { id: "t6", projectId: "101", title: "Testes de responsividade", status: "todo", priority: "medium", dueDate: "2024-06-25" },
];

export const invoices: Invoice[] = [
  { id: "inv-001", clientId: "1", amount: 4000, status: "paid", date: "2024-04-01", dueDate: "2024-04-15", description: "Sinal 50% - Redesign" },
  { id: "inv-002", clientId: "1", amount: 4000, status: "pending", date: "2024-05-01", dueDate: "2024-05-15", description: "Entrega Final - Redesign" },
  { id: "inv-003", clientId: "3", amount: 2500, status: "overdue", date: "2024-04-20", dueDate: "2024-05-05", description: "Portfolio Web" },
  { id: "inv-004", clientId: "1", amount: 3500, status: "paid", date: "2024-03-10", dueDate: "2024-03-20", description: "Identidade Visual" },
];

export const expenses: Expense[] = [
  { id: "exp-1", category: "software", amount: 54.90, date: "2024-05-01", description: "Adobe Creative Cloud" },
  { id: "exp-2", category: "services", amount: 120.00, date: "2024-05-05", description: "Hospedagem Vercel" },
  { id: "exp-3", category: "equipment", amount: 450.00, date: "2024-04-15", description: "SSD Externo" },
];

export const proposals: Proposal[] = [
  { id: "prop-1", clientId: "2", title: "Site Institucional Completo", value: 4500, status: "sent", dateSent: "2024-05-01", validUntil: "2024-05-15", viewCount: 2, lastViewed: "2024-05-02 10:30" },
  { id: "prop-2", clientId: "4", title: "E-commerce EcoLife", value: 12000, status: "draft", dateSent: "2024-05-10", validUntil: "2024-05-25" },
  { id: "prop-3", clientId: "1", title: "Manutenção Mensal", value: 800, status: "accepted", dateSent: "2024-04-20", validUntil: "2024-05-05", viewCount: 5, lastViewed: "2024-04-22 14:00" },
];

export const kpis: KPI[] = [
  { label: "Receita Mensal", value: "R$ 12.500", change: 15, trend: "up" },
  { label: "Projetos Ativos", value: 3, change: 0, trend: "neutral" },
  { label: "Horas Trabalhadas", value: "142h", change: 8, trend: "up" },
  { label: "Propostas Pendentes", value: 2, change: -1, trend: "down" },
];

export const investments: Investment[] = [
  { id: "inv-1", ticker: "PETR4", name: "Petrobras PN", type: "stock", quantity: 100, averagePrice: 32.50, currentPrice: 36.80, totalInvested: 3250, currentTotal: 3680, profit: 430, profitPercent: 13.23 },
  { id: "inv-2", ticker: "HGLG11", name: "CSHG Logística", type: "fii", quantity: 15, averagePrice: 160.00, currentPrice: 164.50, totalInvested: 2400, currentTotal: 2467.50, profit: 67.50, profitPercent: 2.81 },
  { id: "inv-3", ticker: "BTC", name: "Bitcoin", type: "crypto", quantity: 0.005, averagePrice: 300000, currentPrice: 350000, totalInvested: 1500, currentTotal: 1750, profit: 250, profitPercent: 16.67 },
  { id: "inv-4", ticker: "Tesouro Selic", name: "Tesouro Selic 2027", type: "fixed", quantity: 1, averagePrice: 13000, currentPrice: 13450, totalInvested: 13000, currentTotal: 13450, profit: 450, profitPercent: 3.46 },
];

export const notifications: Notification[] = [
  { id: "n1", title: "Proposta Visualizada", message: "Cliente Carlos Mendes abriu a proposta 'Site Institucional'.", type: "success", date: "Há 10 min", read: false },
  { id: "n2", title: "Prazo Próximo", message: "Projeto 'Redesign Website TechFlow' vence em 3 dias.", type: "warning", date: "Há 2 horas", read: false },
  { id: "n3", title: "Fatura Atrasada", message: "Fatura #003 de Studio Vertex venceu ontem.", type: "error", date: "Há 1 dia", read: true },
  { id: "n4", title: "Novo Lead", message: "Novo cadastro pelo site: João Paulo (E-commerce).", type: "info", date: "Há 2 dias", read: true },
];

export const goals: Goal[] = [
  { id: "g1", title: "Faturamento Mensal", current: 12500, target: 20000, unit: "R$", period: "monthly", type: "revenue" },
  { id: "g2", title: "Tarefas Diárias", current: 4, target: 6, unit: "tasks", period: "daily", type: "tasks" },
  { id: "g3", title: "Novos Clientes", current: 1, target: 3, unit: "clients", period: "monthly", type: "clients" },
];
