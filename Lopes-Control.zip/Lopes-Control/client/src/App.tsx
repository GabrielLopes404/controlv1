import { Layout } from "@/components/layout/Layout";
import { Switch, Route } from "wouter";
import Dashboard from "@/pages/Dashboard";
import Clients from "@/pages/Clients";
import Projects from "@/pages/Projects";
import Tasks from "@/pages/Tasks";
import Proposals from "@/pages/Proposals";
import Finance from "@/pages/Finance";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";
import Investments from "@/pages/Investments";
import Goals from "@/pages/Goals";
import Chat from "@/pages/Chat";
import Templates from "@/pages/Templates";
import Calendar from "@/pages/Calendar";
import ClientPortal from "@/pages/ClientPortal";

function App() {
  return (
    <Switch>
      {/* Route for Client Portal (No Dashboard Layout) */}
      <Route path="/portal" component={ClientPortal} />
      
      {/* Routes with Dashboard Layout */}
      <Route>
        <Layout>
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/clients" component={Clients} />
            <Route path="/projects" component={Projects} />
            <Route path="/tasks" component={Tasks} />
            <Route path="/finance" component={Finance} />
            <Route path="/proposals" component={Proposals} />
            <Route path="/reports" component={Reports} />
            <Route path="/settings" component={Settings} />
            <Route path="/investments" component={Investments} />
            <Route path="/goals" component={Goals} />
            <Route path="/chat" component={Chat} />
            <Route path="/templates" component={Templates} />
            <Route path="/calendar" component={Calendar} />
            <Route>
              <div className="text-center py-20">
                <h1 className="text-4xl font-heading font-bold text-primary">404</h1>
                <p className="text-muted-foreground">Página não encontrada</p>
              </div>
            </Route>
          </Switch>
        </Layout>
      </Route>
    </Switch>
  );
}

export default App;
